/*
 * Destructuring
 */

//******************************************************
// Utilisation avec les tableaux
//******************************************************
console.clear()
const nombres = [12,4,5];

// Sans destructuring

// Destructuring "total"


// Destructuring "partielle"


//******************************************************
// Utilisation avec les objets
//*****************************************************
let utilisateur = {
    nom: 'dupond',
    age: 30,
    email: 'dupond@exemple.fr',
}

// Sans destructuring


// Destructuring


// Destructuring avec changement de denomination des variables


//******************************************************
// Destructuring et fonction
// Utilisation principale avec des objets
//*****************************************************

let p1 = {
    nom: 'dupond',
    prenom: 'jean',
    email: 'dupond@exemple.fr'
}

// Création d'une fonction retournant l'identité d'un objet sous la forme "prenom NOM"
// Méthode "classique"


// Méthode "destructuring"
