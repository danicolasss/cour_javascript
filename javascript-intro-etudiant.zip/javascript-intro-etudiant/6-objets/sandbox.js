/*
 * Les objets
 */

// Création d'un objet littéral


// Accès aux attributs (propriétés) d'un objet


// Modification d'un objet


// Copie d'objets (copie par référence)


// Création d'un objet complexe



