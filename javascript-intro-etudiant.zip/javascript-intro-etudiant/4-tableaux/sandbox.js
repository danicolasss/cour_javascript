/*
 * Les tableaux
 */

// Déclaration d'un tableau (exemple :  tableau d'entiers)


// Type d'un tableau


// Accès à un élément


// Taille d'un tableau


// Ajout d'un élément


// Parcours d'un tableau : boucle for


// Parcours du tableau : boucle for-of (accès aux valeurs)


// Parcours du tableau : boucle for-in (accès aux index)


// Copie d'un tableau : opérateur d'affectation = (copie par référence)


// Copie d'un tableau :  Array.from (shallow copie - copie superficielle)


// Quelques méthodes

