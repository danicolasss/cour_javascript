/*
 * Opérateur spread
 */

//******************************************************
// Utilisation avec les tableaux
//******************************************************
console.clear()
const nombres = [12,16,88,66,11]
console.log(nombres)

// Utilisation de l'opérateur spread ...


// Copie de tableau (shallow copie)


// Fusion (concaténation) de tableaux


//******************************************************
// Utilisation avec les objets
//******************************************************
console.clear()
const utilisateur = {
    nom: 'dupond',
    age: 30,
    email: 'dupond@exemple.fr',
    ville: 'Besançon'
}
console.log(utilisateur)

// Copie d'objet (shallow copie)


// Copie d'objet avec modification d'un attribut


// Copie d'objet avec ajout d'un nouvel attribut
