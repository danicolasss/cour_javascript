/*
 *  Les variables
 */

// Déclaration d'une variable


// Déclaration d'une constante


// Déclaration d'une variable initialisée sans valeur explicite : null


// Déclaration d'une variable non initialisée

