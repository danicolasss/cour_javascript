/*
 * Les chaines de caractères
 */

// chaine littérale


// Déclaration d'une variable de type chaine


// Concaténation de chaines


// Accès à un caractère


// Longueur d'une chaine


// Quelques méthodes


// Template string (interpolation)
