/*
 * Les fonctions
 */

// Déclaration d'une fonction (methode "classique")


// Fonction anonyme (à préférer)


// Fonction avec paramètres


// Fonction retournant un résultat


// Fonction fléchée (introduit par ES6)


// Simplification avec un seul paramètre


// Simplification avec une seule instruction return


// Exemple : fonction permettant de calculer le montant total TTC d'un ensemble de produits avec un taux de TVA donné
