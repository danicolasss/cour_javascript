/*
 * Les dates
 */

// Déclaration d'une date


// Quelques méthodes


// Conversion d'une date en chaine


// Conversion d'une date en timestamp


// Comparaison de dates


// Conversion d'un timestamp en date








